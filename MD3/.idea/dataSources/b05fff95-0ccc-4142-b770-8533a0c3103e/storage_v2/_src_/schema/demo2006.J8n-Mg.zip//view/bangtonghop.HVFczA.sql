create definer = root@localhost view bangtonghop as
select `o`.`customerId`                     AS `customerId`,
       `o`.`time`                           AS `time`,
       `demo2006`.`orderdetail`.`orderId`   AS `orderId`,
       `demo2006`.`orderdetail`.`productId` AS `productId`,
       `demo2006`.`orderdetail`.`quantity`  AS `SL_Ban`,
       `p`.`quantity`                       AS `Ton_Kho`,
       `p`.`price`                          AS `price`,
       `p`.`name`                           AS `name`,
       `c`.`name`                           AS `customerName`
from (((`demo2006`.`orderdetail` join `demo2006`.`order` `o`
        on ((`o`.`id` = `demo2006`.`orderdetail`.`orderId`))) join `demo2006`.`customer` `c`
       on ((`c`.`id` = `o`.`customerId`))) join `demo2006`.`product` `p`
      on ((`p`.`id` = `demo2006`.`orderdetail`.`productId`)));

