create definer = root@localhost view totaltable as
select `o`.`customerId` AS `customerId`, `o`.`time` AS `time`
from ((`demo2006`.`orderdetail` join `demo2006`.`order` `o`
       on ((`o`.`id` = `demo2006`.`orderdetail`.`orderId`))) join `demo2006`.`product` `p`
      on ((`p`.`id` = `demo2006`.`orderdetail`.`productId`)));

