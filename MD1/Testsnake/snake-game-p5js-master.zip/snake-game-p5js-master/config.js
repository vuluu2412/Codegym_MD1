const GRID_SIZE = 30;

const WITDH = 600;
const HEIGHT = 600;
const SNAKE_SPEED = 8;

